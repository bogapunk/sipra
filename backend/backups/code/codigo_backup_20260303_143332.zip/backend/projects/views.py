from rest_framework import viewsets
from .models import (
    Eje, Plan, Programa, ObjetivoEstrategico, Indicador,
    Proyecto, ProyectoArea, ProyectoEquipo, Etapa, ComentarioProyecto,
)
from .serializers import (
    EjeSerializer, PlanSerializer, ProgramaSerializer,
    ObjetivoEstrategicoSerializer, IndicadorSerializer,
    ProyectoSerializer, ProyectoAreaSerializer, ProyectoEquipoSerializer,
    EtapaSerializer, ComentarioProyectoSerializer,
)


class EjeViewSet(viewsets.ModelViewSet):
    queryset = Eje.objects.all()
    serializer_class = EjeSerializer


class PlanViewSet(viewsets.ModelViewSet):
    queryset = Plan.objects.select_related('eje').all()
    serializer_class = PlanSerializer

    def get_queryset(self):
        qs = Plan.objects.select_related('eje').all()
        eje = self.request.query_params.get('eje')
        if eje:
            qs = qs.filter(eje_id=eje)
        return qs


class ProgramaViewSet(viewsets.ModelViewSet):
    queryset = Programa.objects.select_related('plan').all()
    serializer_class = ProgramaSerializer

    def get_queryset(self):
        qs = Programa.objects.select_related('plan').all()
        plan = self.request.query_params.get('plan')
        if plan:
            qs = qs.filter(plan_id=plan)
        return qs


class ObjetivoEstrategicoViewSet(viewsets.ModelViewSet):
    queryset = ObjetivoEstrategico.objects.select_related('programa').all()
    serializer_class = ObjetivoEstrategicoSerializer

    def get_queryset(self):
        qs = ObjetivoEstrategico.objects.select_related('programa').all()
        programa = self.request.query_params.get('programa')
        if programa:
            qs = qs.filter(programa_id=programa)
        return qs


class IndicadorViewSet(viewsets.ModelViewSet):
    queryset = Indicador.objects.select_related('proyecto').all()
    serializer_class = IndicadorSerializer

    def get_queryset(self):
        qs = Indicador.objects.select_related('proyecto').all()
        proyecto = self.request.query_params.get('proyecto')
        if proyecto:
            qs = qs.filter(proyecto_id=proyecto)
        return qs


class ProyectoViewSet(viewsets.ModelViewSet):
    queryset = Proyecto.objects.select_related('usuario_responsable', 'area', 'secretaria', 'creado_por')
    serializer_class = ProyectoSerializer

    def get_object(self):
        """Usa queryset sin filtros de listado para retrieve/update/destroy (evita 'No Proyecto matches')."""
        from rest_framework.generics import get_object_or_404
        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field
        lookup_value = self.kwargs[lookup_url_kwarg]
        filter_kwargs = {self.lookup_field: lookup_value}
        if self.action in ('retrieve', 'update', 'partial_update', 'destroy'):
            return get_object_or_404(Proyecto.objects.all(), **filter_kwargs)
        return super().get_object()

    def perform_destroy(self, instance):
        """Elimina en orden para evitar IntegrityError con Tarea->Etapa->Proyecto."""
        from django.db import transaction
        from tasks.models import HistorialTarea
        with transaction.atomic():
            # 1. Historial de tareas, luego tareas (Tarea referencia Etapa con SET_NULL)
            tarea_ids = list(instance.tareas.values_list('id', flat=True))
            HistorialTarea.objects.filter(tarea_id__in=tarea_ids).delete()
            instance.tareas.all().delete()
            # 2. Etapas, Indicadores, Comentarios, ProyectoArea, ProyectoEquipo
            instance.etapas.all().delete()
            instance.indicadores.all().delete()
            instance.comentarios.all().delete()
            instance.proyectoarea_set.all().delete()
            instance.equipo.all().delete()
            # 3. Proyecto
            instance.delete()

    def get_queryset(self):
        qs = Proyecto.objects.select_related(
            'usuario_responsable', 'area', 'secretaria', 'creado_por'
        ).prefetch_related('equipo', 'proyectoarea_set')
        secretaria_id = self.request.query_params.get('secretaria')
        area_id = self.request.query_params.get('area')
        if secretaria_id:
            qs = qs.filter(secretaria_id=secretaria_id)
        if area_id:
            qs = qs.filter(area_id=area_id)
        return qs


class ProyectoEquipoViewSet(viewsets.ModelViewSet):
    queryset = ProyectoEquipo.objects.select_related('proyecto', 'usuario')
    serializer_class = ProyectoEquipoSerializer

    def get_queryset(self):
        qs = ProyectoEquipo.objects.select_related('proyecto', 'usuario')
        proyecto = self.request.query_params.get('proyecto')
        if proyecto:
            qs = qs.filter(proyecto_id=proyecto)
        return qs


class ProyectoAreaViewSet(viewsets.ModelViewSet):
    queryset = ProyectoArea.objects.select_related('proyecto', 'area')
    serializer_class = ProyectoAreaSerializer

    def get_queryset(self):
        qs = ProyectoArea.objects.select_related('proyecto', 'area')
        proyecto = self.request.query_params.get("proyecto")
        if proyecto:
            qs = qs.filter(proyecto_id=proyecto)
        return qs


class EtapaViewSet(viewsets.ModelViewSet):
    queryset = Etapa.objects.select_related('proyecto')
    serializer_class = EtapaSerializer

    def get_queryset(self):
        qs = Etapa.objects.select_related('proyecto')
        proyecto = self.request.query_params.get("proyecto")
        if proyecto:
            qs = qs.filter(proyecto_id=proyecto)
        return qs


class ComentarioProyectoViewSet(viewsets.ModelViewSet):
    queryset = ComentarioProyecto.objects.select_related('proyecto', 'usuario')
    serializer_class = ComentarioProyectoSerializer

    def get_queryset(self):
        qs = ComentarioProyecto.objects.select_related('proyecto', 'usuario')
        proyecto = self.request.query_params.get("proyecto")
        if proyecto:
            qs = qs.filter(proyecto_id=proyecto)
        return qs
